# Movie Theater Movie Management System

This project is a database management system that will be used to keep track of movie tickets sold and seats available. 
The aim with the system is to create a simple to use and accurate storage system of all the movies that are being 
currently shown as well as how many seats are available in that specific theater.