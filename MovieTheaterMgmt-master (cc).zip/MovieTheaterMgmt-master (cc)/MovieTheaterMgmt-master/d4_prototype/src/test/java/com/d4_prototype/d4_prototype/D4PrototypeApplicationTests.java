package com.d4_prototype.d4_prototype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D4PrototypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
