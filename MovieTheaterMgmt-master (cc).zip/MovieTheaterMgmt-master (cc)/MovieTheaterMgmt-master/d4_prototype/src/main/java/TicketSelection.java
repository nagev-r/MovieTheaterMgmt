package com.d4_prototype.d4_prototype;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/tickets")
public class TicketController {

    @Autowired
    private MovieService movieService;

    @GetMapping("/movies")
    public Map<String, Movie> getAllMovies() {
        return movieService.getAllMovies();
    }

    @PostMapping("/book")
    public String bookTicket(@RequestParam String movieId, @RequestParam String showtime) {
        Movie movie = movieService.getMovieById(movieId);
        if (movie == null || !movie.getShowtimes().contains(showtime)) {
            return "Invalid selection.";
        }
        // Simulate booking logic here
        return "Ticket booked for " + movie.getTitle() + " at " + showtime;
    }
}

public class TicketSelection
{

}
