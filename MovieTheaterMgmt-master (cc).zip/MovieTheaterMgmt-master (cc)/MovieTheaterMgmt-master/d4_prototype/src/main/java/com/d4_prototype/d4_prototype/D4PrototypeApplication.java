package com.d4_prototype.d4_prototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D4PrototypeApplication {
	public static void main(String[] args) {
		SpringApplication.run(D4PrototypeApplication.class, args);
	}
}
