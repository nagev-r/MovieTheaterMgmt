Possible frontend for prototype.
